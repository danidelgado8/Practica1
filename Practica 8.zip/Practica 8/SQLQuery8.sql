use ConsultorioMedico

create table Paciente
(Id_Paciente int , Nombre varchar(20) , Apellidos varchar(20) , Edad int , Domicilio text, Id_PacienteExpediente int, Estatus varchar(20));


create table Paciente_Expediente
(Id_Paciente int, Id_Expediente int, Id_PacienteExpediente int );

create table Expediente
(Id_Expediente int , Id_Paciente int, Altura float not null, Peso float not null);


create table Receta
(Id_Receta int , Id_Paciente int, Medicinas text, Fecha datetime, Id_Doctor int);


create table Consulta
(Id_Consulta int , Fecha_Cita datetime, Id_Paciente int, Id_Doctor int, Id_Receta int, Id_Consultorio int);


create index NumPaciente on Paciente (Id_Paciente)
create index NumPacExp on Paciente_Expediente(Id_PacienteExpediente)
create index NumExpediente on Expediente(Id_Expediente)
create index NumReceta on Receta(Id_Receta)
create index Cita on Consulta(Fecha_Cita)

insert into Paciente_Expediente values (1,1,1)
insert into Paciente_Expediente values (2,2,2)
insert into Paciente_Expediente values (3,3,3)
insert into Paciente_Expediente values (4,4,4)
insert into Paciente_Expediente values (5,5,5)
insert into Paciente_Expediente values (6,6,6)
insert into Paciente_Expediente values (7,7,7)
insert into Paciente_Expediente values (8,8,8)
insert into Paciente_Expediente values (8,9,9)
insert into Paciente_Expediente values (10,10,10)
insert into Paciente_Expediente values (11,11,11)
insert into Paciente_Expediente values (12,12,12)
insert into Paciente_Expediente values (13,13,13)
insert into Paciente_Expediente values (14,14,14)
insert into Paciente_Expediente values (15,15,15)

select * from Paciente_Expediente where Id_Paciente = 8
update Paciente_Expediente set Id_PacienteExpediente = 7 where Id_Paciente = 11
delete  from Paciente_Expediente where Id_Paciente = 8
select * from Paciente_Expediente

insert into Paciente values (1,'Daniela', 'Delgado Avalos', 18, 'Fortaleza #747 Monterrey',1,'Paciente agregado')
insert into Paciente values (2,'Evelyn','Delgado Avalos', 15, 'Fortaleza #646 Monterrey',2, 'Paciente agregado')
insert into Paciente values (3,'Fernando', 'Delgado Avalos', 10, 'Fortaleza #747 Monterrey',3,'Paciente agregado')
insert into Paciente values (4,'Veronica','Avalos Medellin', 45, 'Fortaleza #646 Monterrey',4,'Paciente agregado')
insert into Paciente values (5,'Julio Cesar','Diaz', 45, 'Fortaleza #747 Monterrey',5,'Paciente agregado')
insert into Paciente values (6,'Angel','Vergara Gatica', 21,'Acapulco #6800 Guerrero',6,'Paciente agregado')
insert into Paciente values (7,'Diana','Perez Huerta',18, 'Italia #119 Cumbres San Agustin',7,'Paciente no agregado')
insert into Paciente values (8,'Andrea','Flores Garza',19, 'Italia #118 Cumbres San Agustin',8,'Paciente no agregado')
insert into Paciente values (8,'Andrea','Flores Garza',19, 'Italia #118 Cumbres San Agustin',9,'Paciente agregado')
insert into Paciente values (10,'Sabrina', 'Facundo',18,'Fortaleza #878 Barrio Chapultepec',10,'Paciente agregado')
insert into Paciente values (11,'Melanie Aidee', 'Martinez',19,'Saturno #114 Barrio Estrella', 11,'Paciente agregado')
insert into Paciente values (12,'Luis Carlos', 'Quintana',20,'Imposta #354 Mitras Centro',12,'Paciente agregado')
insert into Paciente values (13,'Daniel', 'Mu�oz Guerrero',19, 'Jaramillo #2213 Colonia Mirasol',13,'Paciente agregado')
insert into Paciente values (14,'Astrid Adonai', 'Ortiz',27,'Mar de filipinas #8558 Cedros',14,'Paciente agregado')
insert into Paciente values (15,'Brenda', 'Avalos Medellin',39, 'Ixtapa #777 Saltillo Coahuila',15,'Paciente agregado') 

select * from Paciente where Apellidos = 'Delgado Avalos'
update Paciente set Nombre = 'Daniela Ivon' where Id_PacienteExpediente = 1
delete  from Paciente where Id_Paciente = 8
select * from Paciente

insert into Expediente values (1,1, 1.55, 48.500)
insert into Expediente values (2,2,1.70, 52.00)
insert into Expediente values (3,3,1.50, 40.350)
insert into Expediente values (4,4,1.63, 64.200)
insert into Expediente values (5,5,1.73, 84.398)
insert into Expediente values (6,6,1.80,72.500)
insert into Expediente values (7,7,1.65,56.240)
insert into Expediente values (8,8,1.68,65.900)
insert into Expediente values (8,9,1.68, 64.700)
insert into Expediente values (10,10,1.67, 68.000)
insert into Expediente values (11,11,1.59,45.670)
insert into Expediente values (12,12,1.64,68.379)
insert into Expediente values (13,13,1.56, 76.577)
insert into Expediente values (14,14,1.57, 46.657)
insert into Expediente values (15,15,1.67, 69.948)

select * from Expediente where Id_Paciente = 6
update Expediente set Altura = 1.87 where Id_Paciente = 6
delete  from Expediente where Id_Expediente = 8
select * from Expediente

insert into Receta values (1,1,'Simvastatina',GETDATE(),1)
insert into Receta values (2,2,'Aspirina',GETDATE(),2)
insert into Receta values (3,3,'Omeprazol',GETDATE(),3)
insert into Receta values (4,4,'Ramipril',GETDATE(),4)
insert into Receta values (5,5, 'Amlodipina',GETDATE(),5)
insert into Receta values (6,6,'Paracetamol',GETDATE(),6)
insert into Receta values (7,7,'Lansoprazol',GETDATE(),7)
insert into Receta values (8,8,'Hidrocloruro',GETDATE(),8)
insert into Receta values (8,9, 'Genoprazol',GETDATE(),9)
insert into Receta values (10,10,'Furosemida',GETDATE(),10)
insert into Receta values (11,11,'Ibuprofeno', GETDATE(),11)
insert into Receta values (12,12,'Diclofenaco',GETDATE(),12)
insert into Receta values (13,13, 'Dipirona',GETDATE(),13)
insert into Receta values (14,14,'Amoxicilina',GETDATE(),14)
insert into Receta values (15,15, 'Nimesulida',GETDATE(),15) 

select * from Receta where Id_Receta = 8
update Receta set Id_Paciente = 5 where Id_Doctor = 10
delete  from Receta where Id_Doctor = 15
select * from Receta

insert into Consulta values (1,GETDATE(),1,1,1,1)
insert into Consulta values (2,GETDATE(),2,2,2,2)
insert into Consulta values (3,GETDATE(),3,3,3,3)
insert into Consulta values (4,GETDATE(),4,4,4,4)
insert into Consulta values (5,GETDATE(),5,5,5,5)
insert into Consulta values (6,GETDATE(),6,6,6,6)
insert into Consulta values (7,GETDATE(),7,7,7,7)
insert into Consulta values (8,GETDATE(),8,8,8,8)
insert into Consulta values (8,GETDATE(),9,9,9,9)
insert into Consulta values (10,GETDATE(),10,10,10,10)
insert into Consulta values (11,GETDATE(),11,11,11,11)
insert into Consulta values (12,GETDATE(),12,12,12,12)
insert into Consulta values (13,GETDATE(),13,13,13,13)
insert into Consulta values (14,GETDATE(),14,14,14,14)
insert into Consulta values (15,GETDATE(),15,15,15,15)

select * from Consulta where Id_Consulta = 8
update Consulta set Id_Consultorio = 15 where Id_Doctor = 11
delete from Consulta where Id_Consultorio = 15
select * from Consulta

select Nombre, Apellidos into NombrePaciente from Paciente

select d.Domicilio As 'Direccion' from Paciente as d
select c.Id_PacienteExpediente As 'Control de salud' from Paciente_Expediente as c
select a.Altura As 'Metros', a.Peso as 'Kilogramos' from Expediente as a
select m.Medicinas As 'Nombre medicina' from Receta as m
select f.Fecha_Cita As 'Fecha consulta' from Consulta as f

select Paciente.Nombre, Expediente.Altura from Paciente inner join Expediente on Paciente.Id_Paciente = Expediente.Id_Paciente
select Consulta.Id_Consulta, Receta.Id_Receta from Consulta left join Receta on Consulta.Id_Doctor = Receta.Id_Doctor
select Paciente.Apellidos, Expediente.Peso from Paciente right join Expediente on Paciente.Id_Paciente = Expediente.Id_Paciente
select Id_Expediente, Altura, Peso, Edad from Expediente cross join Paciente

select * from Paciente where Edad<18
select * from Paciente_Expediente where Id_Expediente=8
select * from Expediente where Altura>1.55
select * from Receta where Id_Doctor = 6
select * from Consulta where Id_Consultorio = Id_Consulta

select Peso, AVG(Altura) from Expediente group by Peso
select Id_Receta, count(Id_Paciente) from Receta group by Id_Receta

select Paciente.Nombre, Expediente.Altura from Paciente inner join Expediente on Paciente.Id_Paciente = Expediente.Id_Paciente GROUP BY Edad 

select  Nombre, Apellidos from Paciente where Id_Paciente in  (select Id_PacienteExpediente from Paciente_Expediente where Id_Expediente != Id_PacienteExpediente);
select * from Receta where Id_Doctor in (select Id_Consultorio from Consulta where Id_Consultorio != Id_Doctor);
select  Nombre, Id_Paciente from Paciente where Edad > all   (select Edad from Paciente where Edad < 20);

create view PacienteIndependiente as select Apellidos,Nombre,Edad from Paciente where Edad >= 18;
select * from PacienteIndependiente order by Apellidos

create view NumExpediente as select Id_Paciente, Id_Expediente, Id_PacienteExpediente from Paciente_Expediente where Id_Paciente != Id_PacienteExpediente;
select * from NumExpediente order by Id_Paciente

create view ObesidadPrematura as select  MAX(Peso) as PesoMaximo, MIN(Altura) as AlturaMinimo, AVG(Peso) as PesoPromedio,AVG(Altura) as AlturaPromedio from Expediente; 
select * from ObesidadPrematura where PesoPromedio > =50

create view NumDoctores as select Receta.Id_Doctor, Consulta.Fecha_Cita from Receta inner join Consulta on Receta.Id_Receta = Consulta.Id_Receta;
select * from NumDoctores order by Fecha_Cita DESC

create view Consultas as select Consulta.Id_Paciente, Paciente.Edad FROM Consulta right join Paciente on Consulta.Id_Paciente = Paciente.Id_Paciente;
select * from Consultas order by Edad ASC

select AVG(Peso) as PesoPromedio from Expediente where Exists (select * from Paciente where Edad != 18);


DECLARE  @ConsultaSQL as NVARCHAR(500)
DECLARE @Tabla as nvarchar(50)
DECLARE @Apellidos as nvarchar(20)
DECLARE @Nombre as nvarchar(20)
DECLARE @Parametros as nvarchar(10)
DECLARE @Edad as int

SET @Apellidos = 'Delgado Avalos'
SET @Nombre = 'Daniela Ivon'
SET @Tabla = 'Paciente'
SET @Edad = 18
SET @ConsultaSQL = 'SELECT * FROM '+ @Tabla +' where @Edad = 18'
SET @Parametros = N'@Apellidos as nvarchar(20), @Nombre  as nvarchar(20), @Edad as int'

EXEC SP_EXECUTESQL @ConsultaSQL, N'@Apellidos as nvarchar(20), @Nombre as nvarchar(20), @Edad as int', @Apellidos, @Nombre, @Edad

create procedure Registro_Paciente
 (@Edad int )as
select Nombre, Apellidos from Paciente where @Edad  > 30;
exec Registro_Paciente 35;

create procedure Exp_DPaciente (@Id_Expediente int = 8, @Id_Paciente int = 9) as select Id_PacienteExpediente from Paciente_Expediente where @Id_Expediente = Id_Expediente and @Id_Paciente = Id_Paciente;
exec Exp_DPaciente @Id_Paciente = 9;

create procedure ElExpediente (@Altura float, @Peso float)
as insert into Expediente(Altura, Peso) values (@Altura, @Peso);
exec ElExpediente @Altura = 38.2, @Peso= 60.4; 
SELECT *FROM Expediente


SELECT * FROM Receta
CREATE PROCEDURE NumeroReceta (@Id_Receta int , @Id_Paciente int, @Medicinas text,  @Id_Doctor int) 
as insert into Receta (Id_Receta, Id_Paciente , Medicinas,  Id_Doctor) values (@Id_Receta  , @Id_Paciente , @Medicinas ,  @Id_Doctor )
exec NumeroReceta @Id_Receta = 15, @Id_Paciente = 6, @Medicinas ='Paracetamol', @Id_Doctor = 3;

select * from Consulta


CREATE PROCEDURE PAC.Devolver_Datos_Paciente 
@Edad3 int OUTPUT ,
AS    

    SET NOCOUNT ON;  
    SELECT @Edad3 = Edad3 
    FROM PAC.Edad3 
    WHERE Edad = @Edad3;  
RETURN  
GO  

create trigger NuevoPaciente 
on Paciente 
after insert 
as
insert into Paciente values (16, 'Natalia','Gomez',18, 'Fortaleza #747 Monterrey',1,'Paciente agregado')
  
create trigger ActualizarPaciente
on Paciente 
after update
as
update Paciente SET Edad= 11 WHERE Id_Paciente<= 8


create trigger PacienteEliminado
on Paciente 
instead of delete
as
delete Estatus from Paciente where Edad <= 17
