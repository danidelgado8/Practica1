use ConsultorioMedico

create procedure Registro_Paciente
 (@Edad int )as
select Nombre, Apellidos from Paciente where @Edad  > 30;
exec Registro_Paciente 35;

create procedure Exp_DPaciente (@Id_Expediente int = 8, @Id_Paciente int = 9) as select Id_PacienteExpediente from Paciente_Expediente where @Id_Expediente = Id_Expediente and @Id_Paciente = Id_Paciente;
exec Exp_DPaciente @Id_Paciente = 9;

create procedure ElExpediente (@Altura float, @Peso float)
as insert into Expediente(Altura, Peso) values (@Altura, @Peso);
exec ElExpediente @Altura = 38.2, @Peso= 60.4; 
SELECT *FROM Expediente


SELECT * FROM Receta
CREATE PROCEDURE NumeroReceta (@Id_Receta int , @Id_Paciente int, @Medicinas text,  @Id_Doctor int) 
as insert into Receta (Id_Receta, Id_Paciente , Medicinas,  Id_Doctor) values (@Id_Receta  , @Id_Paciente , @Medicinas ,  @Id_Doctor )
exec NumeroReceta @Id_Receta = 15, @Id_Paciente = 6, @Medicinas ='Paracetamol', @Id_Doctor = 3;

select * from Consulta

CREATE PROCEDURE PAC.Devolver_Datos_Paciente 
@Edad3 int OUTPUT ,
AS    

    SET NOCOUNT ON;  
    SELECT @Edad3 = Edad3 
    FROM PAC.Edad3 
    WHERE Edad = @Edad3;  
RETURN  
GO  


 